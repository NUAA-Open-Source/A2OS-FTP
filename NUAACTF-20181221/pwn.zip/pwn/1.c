#include<stdio.h>

int main(){
    int a = 0;
    printf("1234%n\n",&a);
    printf("%d\n",a);
    
    return 0;
}
